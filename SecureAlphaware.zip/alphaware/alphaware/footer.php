<div id="footer">
    <div class="foot">
        <label style="font-size:17px;"> Copyright &copy; </label>
        <p style="font-size:25px;">Alphaware Inc. 2015</p>
    </div>
    <div id="foot">
        <h4>Links</h4>
        <ul>
            <a href="http://www.facebook.com/alphaware"><li>Facebook</li></a>
            <a href="http://www.twitter.com/alphaware"><li>Twitter</li></a>
            <a href="http://www.pinterest.com/alphaware"><li>Pinterest</li></a>
            <a href="http://www.tumblr.com/alphaware"><li>Tumblr</li></a>
        </ul>
    </div>
</div>

